"""
Step 2: Download the biological assembly for each candidate and apply
automated geometric/quality filters -- no manual PDB inspection.

Filters (tune thresholds as needed):
  1. Chain count matches expected oligomeric state from symmetry symbol
     (C3 -> exactly 3 protein chains, etc.)
  2. All chains are (near-)identical sequence (true homo-oligomer, not a
     hetero-complex that happens to have cyclic symmetry in one entity)
  3. Per-chain length in a usable range for your motif-design use case
     (e.g. 80-400 residues -- drop tiny peptides and huge multidomain proteins)
  4. Real, non-crystallographic interface: BSA per chain-pair > min_bsa
     and at least one chain-pair must be within a plausible bonded distance
     (rules out "symmetry mates" that don't actually touch)
  5. No missing-residue gaps at the would-be interface region (avoids
     building motifs onto disordered termini)

Requires: biotite (pure python, handles mmCIF + assemblies cleanly),
          freesasa (for BSA)
  pip install biotite freesasa --break-system-packages

Output: selected_pdbs.json (target ~100, sorted by quality score)
        + downloaded assembly CIF files in ./assemblies/
"""

import json
import os
import requests
import freesasa
import biotite.structure as struc
import biotite.structure.io.pdbx as pdbx
from collections import Counter

ASSEMBLY_DIR = "assemblies"
os.makedirs(ASSEMBLY_DIR, exist_ok=True)

EXPECTED_CHAINS = {"C2": 2, "C3": 3, "C4": 4, "C5": 5, "C6": 6}
MIN_CHAIN_LEN = 80
MAX_CHAIN_LEN = 400
MIN_BSA = 600.0       # Angstrom^2, per interface, your existing threshold
MAX_SEQ_IDENTITY_SPREAD = 0.02  # chains must be >=98% identical to count as "homo"


def download_assembly(pdb_id: str, assembly_id: int = 1) -> str:
    """Download the first biological assembly as mmCIF."""
    url = f"https://files.rcsb.org/download/{pdb_id}-assembly{assembly_id}.cif.gz"
    out_path = f"{ASSEMBLY_DIR}/{pdb_id}.cif.gz"
    if os.path.exists(out_path):
        return out_path
    r = requests.get(url, timeout=30)
    if r.status_code != 200:
        return None
    with open(out_path, "wb") as f:
        f.write(r.content)
    return out_path


def load_structure(cif_gz_path: str):
    import gzip
    with gzip.open(cif_gz_path, "rt") as f:
        cif_file = pdbx.CIFFile.read(f)
    atoms = pdbx.get_structure(cif_file, model=1)
    atoms = atoms[struc.filter_amino_acids(atoms)]
    return atoms


def chain_sequences(atoms):
    """Rough per-chain sequence (CA residue names) for identity check."""
    seqs = {}
    for chain_id in set(atoms.chain_id):
        chain_atoms = atoms[atoms.chain_id == chain_id]
        ca = chain_atoms[chain_atoms.atom_name == "CA"]
        seqs[chain_id] = "".join(ca.res_name)
    return seqs


def seq_identity(seq_a: str, seq_b: str) -> float:
    if not seq_a or not seq_b:
        return 0.0
    n = min(len(seq_a), len(seq_b))
    matches = sum(a == b for a, b in zip(seq_a[:n], seq_b[:n]))
    return matches / max(len(seq_a), len(seq_b))


def compute_pairwise_bsa(cif_gz_path: str, chain_ids):
    """
    BSA via freesasa: SASA(complex) vs sum(SASA(isolated chains)).
    Returns dict {(chain_a, chain_b): bsa}
    """
    import gzip, tempfile
    # freesasa needs a PDB file; convert via biotite on the fly
    atoms = load_structure(cif_gz_path)

    def sasa_of(selected_chains):
        sub = atoms[struc.filter_amino_acids(atoms)]
        mask = [c in selected_chains for c in sub.chain_id]
        sub = sub[mask]
        tmp = tempfile.NamedTemporaryFile(suffix=".pdb", delete=False)
        import biotite.structure.io.pdb as pdb
        pdb_file = pdb.PDBFile()
        pdb_file.set_structure(sub)
        pdb_file.write(tmp.name)
        struct_fs = freesasa.Structure(tmp.name)
        result = freesasa.calc(struct_fs)
        os.unlink(tmp.name)
        return result.totalArea()

    bsa = {}
    for i, ca in enumerate(chain_ids):
        for cb in chain_ids[i + 1:]:
            sasa_complex = sasa_of([ca, cb])
            sasa_a = sasa_of([ca])
            sasa_b = sasa_of([cb])
            bsa[(ca, cb)] = (sasa_a + sasa_b - sasa_complex) / 2.0
    return bsa


def evaluate_candidate(pdb_id: str, symmetry: str) -> dict:
    cif_gz = download_assembly(pdb_id)
    if cif_gz is None:
        return {"pdb_id": pdb_id, "pass": False, "reason": "download_failed"}

    try:
        atoms = load_structure(cif_gz)
    except Exception as e:
        return {"pdb_id": pdb_id, "pass": False, "reason": f"parse_error: {e}"}

    chain_ids = sorted(set(atoms.chain_id))
    expected_n = EXPECTED_CHAINS[symmetry]

    if len(chain_ids) != expected_n:
        return {"pdb_id": pdb_id, "pass": False,
                 "reason": f"chain_count {len(chain_ids)} != expected {expected_n}"}

    seqs = chain_sequences(atoms)
    lengths = [len(s) for s in seqs.values()]
    if min(lengths) < MIN_CHAIN_LEN or max(lengths) > MAX_CHAIN_LEN:
        return {"pdb_id": pdb_id, "pass": False,
                 "reason": f"chain_length out of range: {lengths}"}

    # pairwise sequence identity -- true homo-oligomer check
    ref_seq = seqs[chain_ids[0]]
    identities = [seq_identity(ref_seq, seqs[c]) for c in chain_ids[1:]]
    if min(identities) < (1 - MAX_SEQ_IDENTITY_SPREAD):
        return {"pdb_id": pdb_id, "pass": False,
                 "reason": f"not homo-oligomer, min seq identity {min(identities):.2f}"}

    try:
        bsa = compute_pairwise_bsa(cif_gz, chain_ids)
    except Exception as e:
        return {"pdb_id": pdb_id, "pass": False, "reason": f"bsa_calc_error: {e}"}

    real_interfaces = {pair: val for pair, val in bsa.items() if val >= MIN_BSA}
    if len(real_interfaces) == 0:
        return {"pdb_id": pdb_id, "pass": False,
                 "reason": f"no interface above {MIN_BSA} A^2, max was {max(bsa.values()):.0f}"}

    quality_score = sum(real_interfaces.values()) / len(real_interfaces)

    return {
        "pdb_id": pdb_id,
        "symmetry": symmetry,
        "pass": True,
        "n_chains": len(chain_ids),
        "chain_length": lengths[0],
        "bsa_per_interface": {f"{a}-{b}": round(v, 1) for (a, b), v in bsa.items()},
        "mean_real_interface_bsa": round(quality_score, 1),
    }


def download_only(candidates):
    """Network-bound phase -- run on a login node."""
    for i, cand in enumerate(candidates):
        path = download_assembly(cand["pdb_id"])
        status = "ok" if path else "FAILED"
        print(f"[{i+1}/{len(candidates)}] {cand['pdb_id']}: {status}")


def filter_only(candidates):
    """CPU-bound phase. Files must already be in ./assemblies/ -- safe to run via sbatch with no network."""
    results = []
    for i, cand in enumerate(candidates):
        print(f"[{i+1}/{len(candidates)}] {cand['pdb_id']} ({cand['symmetry']})...", end=" ")
        res = evaluate_candidate(cand["pdb_id"], cand["symmetry"])
        print("PASS" if res["pass"] else f"FAIL: {res.get('reason')}")
        results.append(res)
    return results


if __name__ == "__main__":
    import sys
    with open("candidates.json") as f:
        candidates = json.load(f)

    mode = sys.argv[1] if len(sys.argv) > 1 else "all"

    if mode == "download":
        download_only(candidates)
        sys.exit(0)

    # "filter" mode (files pre-downloaded) and "all" mode (lazy download
    # inside evaluate_candidate) both land here
    results = filter_only(candidates)

    passed = [r for r in results if r["pass"]]
    passed.sort(key=lambda r: r["mean_real_interface_bsa"], reverse=True)

    # cap at 100, keeping a spread across symmetries rather than all-C3
    target_n = 100
    by_symmetry = {}
    for r in passed:
        by_symmetry.setdefault(r["symmetry"], []).append(r)

    selected = []
    # round-robin across symmetry classes so you don't end up with 90 C3s
    while len(selected) < target_n and any(by_symmetry.values()):
        for sym in list(by_symmetry.keys()):
            if by_symmetry[sym]:
                selected.append(by_symmetry[sym].pop(0))
            if len(selected) >= target_n:
                break

    with open("selected_pdbs.json", "w") as f:
        json.dump(selected, f, indent=2)

    print(f"\n{len(passed)} total passed filters, selected top {len(selected)} -> selected_pdbs.json")
    print("Symmetry breakdown:", Counter(r["symmetry"] for r in selected))

#!/bin/bash
# setup_curation_env.sh
# Run this on a Sherlock LOGIN node (needs internet for pip).
#
# Usage:
#   ssh lzhou64@login.sherlock.stanford.edu
#   cd /scratch/users/lzhou64/caliby
#   bash setup_curation_env.sh

set -e

PROJECT_DIR=/scratch/users/lzhou64/caliby
CURATION_DIR=$PROJECT_DIR/pdb_curation
SHARED_ENVS=$PROJECT_DIR/envs

mkdir -p "$CURATION_DIR"/{assemblies,logs}
cd "$CURATION_DIR"

echo "== Checking shared possu envs for existing biotite/freesasa install =="
if [ -d "$SHARED_ENVS" ]; then
    for env in "$SHARED_ENVS"/*/; do
        env_name=$(basename "$env")
        if [ -f "$env/bin/python" ]; then
            has_biotite=$("$env/bin/python" -c "import biotite" 2>/dev/null && echo yes || echo no)
            has_freesasa=$("$env/bin/python" -c "import freesasa" 2>/dev/null && echo yes || echo no)
            echo "  $env_name: biotite=$has_biotite freesasa=$has_freesasa"
        fi
    done
fi
echo "If one of the above already has both packages, just activate that env"
echo "and SKIP the venv creation below -- e.g.:"
echo "  source $SHARED_ENVS/protpardelle/bin/activate"
echo ""
read -p "Create a dedicated curation venv anyway? [y/N] " ans
if [[ "$ans" != "y" && "$ans" != "Y" ]]; then
    echo "Skipping venv creation. Activate your chosen shared env and re-run."
    exit 0
fi

echo "== Creating dedicated venv: $CURATION_DIR/env =="
module load python/3.9.0 2>/dev/null || module load python/3.12.1 2>/dev/null || true
python3 -m venv "$CURATION_DIR/env"
source "$CURATION_DIR/env/bin/activate"

pip install --upgrade pip --break-system-packages
pip install requests biotite freesasa numpy --break-system-packages

echo ""
echo "Done. Activate with:"
echo "  source $CURATION_DIR/env/bin/activate"

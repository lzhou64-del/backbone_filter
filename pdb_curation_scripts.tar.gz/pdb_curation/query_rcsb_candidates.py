"""
Step 1: Pull a candidate list of cyclic homo-oligomers from RCSB Search API.

Filters applied server-side (no manual browsing needed):
  - rcsb_struct_symmetry.symbol in {C2, C3, C4, C5, C6}  (cyclic point groups)
  - resolution <= 2.8 A (X-ray) -- relax/drop if you want cryo-EM too
  - polymer entity count consistent with the oligomeric state
    (we cross-check this in Step 2, since the symmetry annotation
    describes the *assembly*, not guaranteed identical chain count)

Output: candidates.json -- list of {pdb_id, symmetry, resolution}
"""

import requests
import json
import time

SEARCH_URL = "https://search.rcsb.org/rcsbsearch/v2/query"

SYMMETRIES = ["C2", "C3", "C4", "C5", "C6"]


def build_query(symmetry: str, max_resolution: float = 2.8) -> dict:
    return {
        "query": {
            "type": "group",
            "logical_operator": "and",
            "nodes": [
                {
                    "type": "terminal",
                    "service": "text",
                    "parameters": {
                        "attribute": "rcsb_struct_symmetry.symbol",
                        "operator": "exact_match",
                        "value": symmetry,
                    },
                },
                {
                    "type": "terminal",
                    "service": "text",
                    "parameters": {
                        "attribute": "rcsb_struct_symmetry.type",
                        "operator": "exact_match",
                        "value": "Cyclic",
                    },
                },
                {
                    "type": "terminal",
                    "service": "text",
                    "parameters": {
                        "attribute": "rcsb_entry_info.resolution_combined",
                        "operator": "less_or_equal",
                        "value": max_resolution,
                    },
                },
                {
                    "type": "terminal",
                    "service": "text",
                    "parameters": {
                        "attribute": "rcsb_entry_info.polymer_entity_count_protein",
                        "operator": "equals",
                        "value": 1,  # homo-oligomer: one unique protein entity
                    },
                },
            ],
        },
        "return_type": "entry",
        "request_options": {
            "paginate": {"start": 0, "rows": 200},
            "results_content_type": ["experimental"],
        },
    }


def fetch_candidates():
    all_hits = []
    for sym in SYMMETRIES:
        q = build_query(sym)
        resp = requests.post(SEARCH_URL, json=q, timeout=30)
        if resp.status_code != 200:
            print(f"  [{sym}] query failed: {resp.status_code} {resp.text[:200]}")
            continue
        data = resp.json()
        ids = [hit["identifier"] for hit in data.get("result_set", [])]
        print(f"  {sym}: {len(ids)} hits")
        for pid in ids:
            all_hits.append({"pdb_id": pid, "symmetry": sym})
        time.sleep(0.5)  # be polite to the API
    return all_hits


if __name__ == "__main__":
    print("Querying RCSB for cyclic homo-oligomers...")
    candidates = fetch_candidates()
    print(f"\nTotal candidates across C2-C6: {len(candidates)}")

    with open("candidates.json", "w") as f:
        json.dump(candidates, f, indent=2)
    print("Saved -> candidates.json")

"""
Step 2: Download the biological assembly for each candidate and apply
automated geometric/quality filters -- no manual PDB inspection.

Filters (tune thresholds as needed):
  1. Chain count matches expected oligomeric state from symmetry symbol
     (C3 -> exactly 3 protein chains, etc.)
  2. All chains are (near-)identical sequence (true homo-oligomer, not a
     hetero-complex that happens to have cyclic symmetry in one entity)
  3. Per-chain length in a usable range for your motif-design use case
     (e.g. 80-400 residues -- drop tiny peptides and huge multidomain proteins)
  4. Real, non-crystallographic interface: BSA per chain-pair > min_bsa
     and at least one chain-pair must be within a plausible bonded distance
     (rules out "symmetry mates" that don't actually touch)
  5. No missing-residue gaps at the would-be interface region (avoids
     building motifs onto disordered termini)

Requires: biotite (pure python, handles mmCIF + assemblies cleanly),
          freesasa (for BSA)
  pip install biotite freesasa --break-system-packages

Output: selected_pdbs.json (target ~100, sorted by quality score)
        + downloaded assembly CIF files in ./assemblies/
"""

import json
import os
import requests
import freesasa
import biotite.structure as struc
import biotite.structure.io.pdbx as pdbx
from collections import Counter

ASSEMBLY_DIR = "assemblies"
os.makedirs(ASSEMBLY_DIR, exist_ok=True)

EXPECTED_CHAINS = {"C2": 2, "C3": 3, "C4": 4, "C5": 5, "C6": 6}
MIN_CHAIN_LEN = 80
MAX_CHAIN_LEN = 400
MIN_BSA = 600.0       # Angstrom^2, per interface, your existing threshold
MAX_SEQ_IDENTITY_SPREAD = 0.02  # chains must be >=98% identical to count as "homo"


def download_assembly(pdb_id: str, assembly_id: int = 1) -> str:
    """Download a specific biological assembly as mmCIF.

    For assembly_id=1, reuses the legacy filename ({pdb_id}.cif.gz) so
    already-downloaded files aren't re-fetched. Fallback assemblies use
    a distinct filename so they don't collide.
    """
    legacy_path = f"{ASSEMBLY_DIR}/{pdb_id}.cif.gz"
    if assembly_id == 1 and os.path.exists(legacy_path) and os.path.getsize(legacy_path) > 0:
        return legacy_path

    out_path = legacy_path if assembly_id == 1 else f"{ASSEMBLY_DIR}/{pdb_id}_assembly{assembly_id}.cif.gz"
    if os.path.exists(out_path) and os.path.getsize(out_path) > 0:
        return out_path

    url = f"https://files.rcsb.org/download/{pdb_id}-assembly{assembly_id}.cif.gz"
    r = requests.get(url, timeout=30)
    if r.status_code != 200:
        return None
    with open(out_path, "wb") as f:
        f.write(r.content)
    return out_path


def load_structure(cif_gz_path: str):
    import gzip
    with gzip.open(cif_gz_path, "rt") as f:
        cif_file = pdbx.CIFFile.read(f)
    atoms = pdbx.get_structure(cif_file, model=1)
    atoms = atoms[struc.filter_amino_acids(atoms)]
    return atoms


def chain_sequences(atoms):
    """Rough per-chain sequence (CA residue names) for identity check."""
    seqs = {}
    for chain_id in set(atoms.chain_id):
        chain_atoms = atoms[atoms.chain_id == chain_id]
        ca = chain_atoms[chain_atoms.atom_name == "CA"]
        seqs[chain_id] = "".join(ca.res_name)
    return seqs


def seq_identity(seq_a: str, seq_b: str) -> float:
    if not seq_a or not seq_b:
        return 0.0
    n = min(len(seq_a), len(seq_b))
    matches = sum(a == b for a, b in zip(seq_a[:n], seq_b[:n]))
    return matches / max(len(seq_a), len(seq_b))


def compute_pairwise_bsa(cif_gz_path: str, chain_ids):
    """
    BSA via freesasa: SASA(complex) vs sum(SASA(isolated chains)).
    Returns dict {(chain_a, chain_b): bsa}

    Legacy PDB format only supports single-character chain IDs, but
    expanded biological assemblies often use multi-character IDs
    (e.g. 'AA', 'BA') once they run past A-Z. We remap to single
    letters/digits just for the PDB conversion step; the returned
    dict keys still use the original chain_ids passed in.
    """
    import tempfile
    atoms = load_structure(cif_gz_path)

    # build a remapping: original chain_id -> single legacy-PDB-safe char
    legacy_charset = (
        [chr(c) for c in range(ord("A"), ord("Z") + 1)]
        + [chr(c) for c in range(ord("0"), ord("9") + 1)]
        + [chr(c) for c in range(ord("a"), ord("z") + 1)]
    )
    if len(chain_ids) > len(legacy_charset):
        raise ValueError(f"too many chains ({len(chain_ids)}) to remap to single-char IDs")
    remap = {orig: legacy_charset[i] for i, orig in enumerate(chain_ids)}

    def sasa_of(selected_chains):
        sub = atoms[struc.filter_amino_acids(atoms)]
        mask = [c in selected_chains for c in sub.chain_id]
        sub = sub[mask]
        # apply remap before writing -- avoids "chain ID exceeds 1 character"
        sub = sub.copy()
        sub.chain_id = [remap[c] for c in sub.chain_id]

        tmp = tempfile.NamedTemporaryFile(suffix=".pdb", delete=False)
        import biotite.structure.io.pdb as pdb
        pdb_file = pdb.PDBFile()
        pdb_file.set_structure(sub)
        pdb_file.write(tmp.name)
        struct_fs = freesasa.Structure(tmp.name)
        result = freesasa.calc(struct_fs)
        os.unlink(tmp.name)
        return result.totalArea()

    bsa = {}
    for i, ca in enumerate(chain_ids):
        for cb in chain_ids[i + 1:]:
            sasa_complex = sasa_of([ca, cb])
            sasa_a = sasa_of([ca])
            sasa_b = sasa_of([cb])
            bsa[(ca, cb)] = (sasa_a + sasa_b - sasa_complex) / 2.0
    return bsa


def evaluate_candidate(pdb_id: str, symmetry: str, max_assembly_id: int = 2) -> dict:
    expected_n = EXPECTED_CHAINS[symmetry]
    last_reason = None

    for assembly_id in range(1, max_assembly_id + 1):
        cif_gz = download_assembly(pdb_id, assembly_id=assembly_id)
        if cif_gz is None:
            last_reason = f"download_failed (assembly{assembly_id})"
            continue

        try:
            atoms = load_structure(cif_gz)
        except Exception as e:
            last_reason = f"parse_error (assembly{assembly_id}): {e}"
            continue

        chain_ids = sorted(set(atoms.chain_id))

        if len(chain_ids) != expected_n:
            last_reason = f"chain_count {len(chain_ids)} != expected {expected_n} (assembly{assembly_id})"
            continue  # try the next assembly_id instead of giving up immediately

        # found an assembly with the right chain count -- proceed with full checks
        break
    else:
        # loop completed without breaking -- no assembly matched chain count
        return {"pdb_id": pdb_id, "pass": False, "reason": last_reason}

    seqs = chain_sequences(atoms)
    lengths = [len(s) for s in seqs.values()]
    if min(lengths) < MIN_CHAIN_LEN or max(lengths) > MAX_CHAIN_LEN:
        return {"pdb_id": pdb_id, "pass": False,
                 "reason": f"chain_length out of range: {lengths}"}

    # pairwise sequence identity -- true homo-oligomer check
    ref_seq = seqs[chain_ids[0]]
    identities = [seq_identity(ref_seq, seqs[c]) for c in chain_ids[1:]]
    if min(identities) < (1 - MAX_SEQ_IDENTITY_SPREAD):
        return {"pdb_id": pdb_id, "pass": False,
                 "reason": f"not homo-oligomer, min seq identity {min(identities):.2f}"}

    try:
        bsa = compute_pairwise_bsa(cif_gz, chain_ids)
    except Exception as e:
        return {"pdb_id": pdb_id, "pass": False, "reason": f"bsa_calc_error: {e}"}

    real_interfaces = {pair: val for pair, val in bsa.items() if val >= MIN_BSA}
    if len(real_interfaces) == 0:
        return {"pdb_id": pdb_id, "pass": False,
                 "reason": f"no interface above {MIN_BSA} A^2, max was {max(bsa.values()):.0f}"}

    quality_score = sum(real_interfaces.values()) / len(real_interfaces)

    return {
        "pdb_id": pdb_id,
        "symmetry": symmetry,
        "pass": True,
        "assembly_id": assembly_id,
        "n_chains": len(chain_ids),
        "chain_length": lengths[0],
        "bsa_per_interface": {f"{a}-{b}": round(v, 1) for (a, b), v in bsa.items()},
        "mean_real_interface_bsa": round(quality_score, 1),
    }


def download_only(candidates):
    """Network-bound phase -- run on a login node, ideally inside tmux."""
    import time
    n_ok, n_fail, n_skip = 0, 0, 0
    for i, cand in enumerate(candidates):
        out_path = f"{ASSEMBLY_DIR}/{cand['pdb_id']}.cif.gz"
        if os.path.exists(out_path) and os.path.getsize(out_path) > 0:
            n_skip += 1
            continue  # resumable: don't re-download what you already have

        path = None
        for attempt in range(3):
            path = download_assembly(cand["pdb_id"])
            if path:
                break
            time.sleep(2 * (attempt + 1))  # backoff on failure

        if path:
            n_ok += 1
        else:
            n_fail += 1
            print(f"[{i+1}/{len(candidates)}] {cand['pdb_id']}: FAILED after 3 attempts")

        if (i + 1) % 50 == 0:
            print(f"[{i+1}/{len(candidates)}] ok={n_ok} fail={n_fail} skipped={n_skip}")

        time.sleep(0.2)  # be polite to files.rcsb.org

    print(f"\nDownload complete: {n_ok} downloaded, {n_skip} already present, {n_fail} failed")


def filter_only(candidates, checkpoint_path="filter_checkpoint.json", checkpoint_every=100):
    """CPU-bound phase. Files must already be in ./assemblies/ -- safe to run via sbatch with no network.

    Resumable: writes results to checkpoint_path periodically, and on
    restart skips any pdb_id already present in that checkpoint file.
    """
    results = []
    done_ids = set()
    if os.path.exists(checkpoint_path):
        with open(checkpoint_path) as f:
            results = json.load(f)
        done_ids = {r["pdb_id"] for r in results}
        print(f"Resuming from checkpoint: {len(results)} already evaluated", flush=True)

    for i, cand in enumerate(candidates):
        if cand["pdb_id"] in done_ids:
            continue
        print(f"[{i+1}/{len(candidates)}] {cand['pdb_id']} ({cand['symmetry']})...", end=" ", flush=True)
        res = evaluate_candidate(cand["pdb_id"], cand["symmetry"])
        print("PASS" if res["pass"] else f"FAIL: {res.get('reason')}", flush=True)
        results.append(res)

        if len(results) % checkpoint_every == 0:
            with open(checkpoint_path, "w") as f:
                json.dump(results, f)

    with open(checkpoint_path, "w") as f:
        json.dump(results, f)
    return results


if __name__ == "__main__":
    import sys
    with open("candidates.json") as f:
        candidates = json.load(f)

    mode = sys.argv[1] if len(sys.argv) > 1 else "all"

    if mode == "download":
        download_only(candidates)
        sys.exit(0)

    # "filter" mode (files pre-downloaded) and "all" mode (lazy download
    # inside evaluate_candidate) both land here
    results = filter_only(candidates)

    passed = [r for r in results if r["pass"]]
    passed.sort(key=lambda r: r["mean_real_interface_bsa"], reverse=True)

    # cap at 100, keeping a spread across symmetries rather than all-C3
    target_n = 100
    by_symmetry = {}
    for r in passed:
        by_symmetry.setdefault(r["symmetry"], []).append(r)

    selected = []
    # round-robin across symmetry classes so you don't end up with 90 C3s
    while len(selected) < target_n and any(by_symmetry.values()):
        for sym in list(by_symmetry.keys()):
            if by_symmetry[sym]:
                selected.append(by_symmetry[sym].pop(0))
            if len(selected) >= target_n:
                break

    with open("selected_pdbs.json", "w") as f:
        json.dump(selected, f, indent=2)

    print(f"\n{len(passed)} total passed filters, selected top {len(selected)} -> selected_pdbs.json")
    print("Symmetry breakdown:", Counter(r["symmetry"] for r in selected))

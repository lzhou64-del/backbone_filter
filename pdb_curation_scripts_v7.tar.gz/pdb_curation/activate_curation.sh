#!/bin/bash
# source this instead of manually re-typing module loads + LD_LIBRARY_PATH
# usage: source activate_curation.sh

module load python/3.9.0
module load gcc/12.4.0
export LD_LIBRARY_PATH=/share/software/user/open/gcc/12.4.0/lib64:$LD_LIBRARY_PATH
source /scratch/users/lzhou64/caliby/pdb_curation/env/bin/activate

echo "Curation env active (python 3.9.0, gcc 12.4.0 libstdc++ on LD_LIBRARY_PATH)"
